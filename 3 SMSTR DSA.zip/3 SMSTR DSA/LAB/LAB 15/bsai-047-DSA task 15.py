#question no 1
def solve_n_queens(n):
    def is_valid(board, row, col):
        for i in range(row):
            if board[i] == col or \
               board[i] - i == col - row or \
               board[i] + i == col + row:
                return False
        return True

    def solve(board, row, solutions):
        if row == n:
            solutions.append(["." * i + "Q" + "." * (n - i - 1) for i in board])
            return
        for col in range(n):
            if is_valid(board, row, col):
                board[row] = col
                solve(board, row + 1, solutions)
                board[row] = -1 

    solutions = []
    solve([-1] * n, 0, solutions)
    return solutions

# test case
result = solve_n_queens(4)
for solution in result:
    for row in solution:
        print(row)
    print()
    
#question no 2
def permute(s):
    def backtrack(start, end, path, results):
        if start == end:
            results.append("".join(path))
        for i in range(start, end):
            if i > start and s[i] == s[start]:
                continue 
            path[start], path[i] = path[i], path[start]
            backtrack(start + 1, end, path, results)
            path[start], path[i] = path[i], path[start] 

    results = []
    backtrack(0, len(s), list(s), results)
    return results

# test case
print(permute("ABC"))
#question no 3

def solve_sudoku(board):
    def is_valid(board, r, c, num):
        
        for i in range(9):
            if board[r][i] == num:
                return False
       
        for i in range(9):
            if board[i][c] == num:
                return False
       
        start_row, start_col = 3 * (r // 3), 3 * (c // 3)
        for i in range(start_row, start_row + 3):
            for j in range(start_col, start_col + 3):
                if board[i][j] == num:
                    return False
        return True

    def backtrack(board):
        for r in range(9):
            for c in range(9):
                if board[r][c] == 0:  
                    for num in range(1, 10):
                        if is_valid(board, r, c, num):
                            board[r][c] = num
                            if backtrack(board):
                                return True
                            board[r][c] = 0  
                    return False
        return True  

    backtrack(board)

# test cases
sudoku_board = [
    [5, 3, 0, 0, 7, 0, 0, 0, 0],
    [6, 0, 0, 1, 9, 5, 0, 0, 0],
    [0, 9, 8, 0, 0, 0, 0, 6, 0],
    [8, 0, 0, 0, 6, 0, 0, 0, 3],
    [4, 0, 0, 8, 0, 3, 0, 0, 1],
    [7, 0, 0, 0, 2, 0, 0, 0, 6],
    [0, 6, 0, 0, 0, 0, 2, 8, 0],
    [0, 0, 0, 4, 1, 9, 0, 0, 5],
    [0, 0, 0, 0, 8, 0, 0, 7, 9]
]

solve_sudoku(sudoku_board)

for row in sudoku_board:
    print(row)
    