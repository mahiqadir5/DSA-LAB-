#question no 1
class Node:
    def __init__(self, key, value):
        self.key = key
        self.value = value
        self.next = None

class HashTableChaining:
    def __init__(self, size=10):
        self.size = size
        self.table = [None] * self.size

    def hash_function(self, key):
        return hash(key) % self.size

    def insert(self, key, value):
        idx = self.hash_function(key)
        new_node = Node(key, value)
        if not self.table[idx]:
            self.table[idx] = new_node
        else:
            current = self.table[idx]
            while current.next:
                if current.key == key:
                    current.value = value
                    return
                current = current.next
            if current.key == key:
                current.value = value
            else:
                current.next = new_node

    def get(self, key):
        idx = self.hash_function(key)
        current = self.table[idx]
        while current:
            if current.key == key:
                return current.value
            current = current.next
        return None

    def delete(self, key):
        idx = self.hash_function(key)
        current = self.table[idx]
        prev = None
        while current:
            if current.key == key:
                if prev:
                    prev.next = current.next
                else:
                    self.table[idx] = current.next
                return
            prev = current
            current = current.next

    def display(self):
        for idx, node in enumerate(self.table):
            print(f"Index {idx}:", end=" ")
            current = node
            while current:
                print(f"({current.key}: {current.value})", end=" -> ")
                current = current.next
            print("None")

class HashTableLinearProbing:
    def __init__(self, size=10):
        self.size = size
        self.table = [None] * self.size

    def hash_function(self, key):
        return hash(key) % self.size

    def insert(self, key, value):
        idx = self.hash_function(key)
        start_idx = idx
        while self.table[idx] is not None and self.table[idx][0] != key:
            idx = (idx + 1) % self.size
            if idx == start_idx:
                raise Exception("Hash Table is full!")

        self.table[idx] = (key, value)

    def get(self, key):
        idx = self.hash_function(key)
        start_idx = idx
        while self.table[idx]:
            if self.table[idx][0] == key:
                return self.table[idx][1]
            idx = (idx + 1) % self.size
            if idx == start_idx:
                break
        return None

    def delete(self, key):
        idx = self.hash_function(key)
        start_idx = idx
        while self.table[idx]:
            if self.table[idx][0] == key:
                self.table[idx] = None
                return
            idx = (idx + 1) % self.size
            if idx == start_idx:
                break

    def display(self):
        for idx, item in enumerate(self.table):
            print(f"Index {idx}: {item}")

# test cases of both implementations
# Chaining Test
print("Chaining Hash Table:")
ht_chain = HashTableChaining(10)
ht_chain.insert("apple", 1)
ht_chain.insert("banana", 2)
ht_chain.insert("grape", 3)
ht_chain.display()
print("Get 'banana':", ht_chain.get("banana"))
ht_chain.delete("banana")
ht_chain.display()

# Linear Probing Test
print("\nLinear Probing Hash Table:")
ht_linear = HashTableLinearProbing(10)
ht_linear.insert("apple", 1)
ht_linear.insert("banana", 2)
ht_linear.insert("grape", 3)
ht_linear.display()
print("Get 'grape':", ht_linear.get("grape"))
ht_linear.delete("banana")
ht_linear.display()

#question no 2
def are_anagrams(str1, str2):
    if len(str1) != len(str2):
        return False

    char_count = {}

    for char in str1:
        char_count[char] = char_count.get(char, 0) + 1

    for char in str2:
        if char not in char_count:
            return False
        char_count[char] -= 1
        if char_count[char] < 0:
            return False

    return True

# test cases
print(are_anagrams("listen", "silent"))  
print(are_anagrams("hello", "world"))   
print(are_anagrams("anagram", "nagaram"))
print(are_anagrams("rat", "car"))

#question no 3
class Node:
    def __init__(self, key, value):
        self.key = key
        self.value = value
        self.prev = None
        self.next = None

class LRUCache:
    def __init__(self, capacity):
        self.capacity = capacity
        self.cache = {}
        self.head = Node(0, 0)  # Dummy head
        self.tail = Node(0, 0)  # Dummy tail
        self.head.next = self.tail
        self.tail.prev = self.head

    def _add_node(self, node):
        # Always add node right after head
        node.prev = self.head
        node.next = self.head.next
        self.head.next.prev = node
        self.head.next = node

    def _remove_node(self, node):
        # Remove an existing node
        prev = node.prev
        new = node.next
        prev.next = new
        new.prev = prev

    def _move_to_front(self, node):
        self._remove_node(node)
        self._add_node(node)

    def _pop_tail(self):
        res = self.tail.prev
        self._remove_node(res)
        return res

    def get(self, key):
        node = self.cache.get(key, None)
        if not node:
            return None
        self._move_to_front(node)
        return node.value

    def put(self, key, value):
        node = self.cache.get(key)

        if not node:
            new_node = Node(key, value)
            self.cache[key] = new_node
            self._add_node(new_node)

            if len(self.cache) > self.capacity:
                tail = self._pop_tail()
                del self.cache[tail.key]
        else:
            node.value = value
            self._move_to_front(node)

    def display(self):
        current = self.head.next
        result = {}
        while current != self.tail:
            result[current.key] = current.value
            current = current.next
        print("Cache State:", result)

# test cases
cache = LRUCache(5)
cache.put(1, "A")
cache.put(2, "B")
cache.put(3, "C")
cache.put(4, "D")
cache.put(5, "E")
cache.display()

cache.get(2) 
cache.put(6, "F")  
cache.display()

cache.get(3)
cache.put(7, "G") 
cache.display()