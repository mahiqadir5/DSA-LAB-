#question no 1
def linear_search(arr, target):
    for i in range(len(arr)):
        if arr[i] == target:
            return i 
    return -1  
def binary_search(arr, target):
    low = 0
    high = len(arr) - 1
    
    while low <= high:
        mid = (low + high) // 2
        if arr[mid] == target:
            return mid  
        elif arr[mid] < target:
            low = mid + 1
        else:
            high = mid - 1
            
    return -1  
import random
import time

# Measure execution time for each search algorithm
def measure_time(search_algorithm, arr, target):
    start_time = time.time()
    search_algorithm(arr, target)
    end_time = time.time()
    return end_time - start_time

input_sizes = [1000, 5000, 10000]
for size in input_sizes:
    unsorted_arr = random.sample(range(size*10), size)
    sorted_arr = sorted(unsorted_arr)
    target = random.choice(unsorted_arr)
    print(f"Input size: {size}")
    print(f"Linear Search Time: {measure_time(linear_search, unsorted_arr, target)} seconds")
    print(f"Binary Search Time: {measure_time(binary_search, sorted_arr, target)} seconds")
    print("-" * 40)
    
#question no 2
def linear_search(arr, target):
    for i in range(len(arr)):
        if arr[i] == target:
            return i 
    return -1  
def binary_search(arr, target):
    low = 0
    high = len(arr) - 1
    
    while low <= high:
        mid = (low + high) // 2
        if arr[mid] == target:
            return mid  
        elif arr[mid] < target:
            low = mid + 1
        else:
            high = mid - 1
            
    return -1  
import random
import time
import matplotlib.pyplot as plt
def measure_time(search_algorithm, arr, target):
    start_time = time.time()
    search_algorithm(arr, target)
    end_time = time.time()
    return end_time - start_time

input_sizes = [1000, 5000, 10000]
for size in input_sizes:
    unsorted_arr = random.sample(range(size*10), size)
    sorted_arr = sorted(unsorted_arr)
    target = random.choice(unsorted_arr)
    print(f"Input size: {size}")
    print(f"Linear Search Time: {measure_time(linear_search, unsorted_arr, target)} seconds")
    print(f"Binary Search Time: {measure_time(binary_search, sorted_arr, target)} seconds")
    print("-" * 40)
    
#question no 2

import math

def jump_search(arr, target):
    n = len(arr)
    step = int(math.sqrt(n))  
    prev = 0
    while arr[min(step, n)-1] < target:
        prev = step
        step += int(math.sqrt(n))
        if prev >= n:
            return -1
    for i in range(prev, min(step, n)):
        if arr[i] == target:
            return i  
    
    return -1  
def interpolation_search(arr, target):
    low = 0
    high = len(arr) - 1
    
    while low <= high and target >= arr[low] and target <= arr[high]:
        pos = low + int(((target - arr[low]) * (high - low)) / (arr[high] - arr[low]))
        if arr[pos] == target:
            return pos
        
        if arr[pos] < target:
            low = pos + 1
        else:
            high = pos - 1
    
    return -1  
jump_search_times = []
interpolation_search_times = []
binary_search_times = []

input_sizes = [1000, 5000, 10000]

for size in input_sizes:
    sorted_arr = sorted(random.sample(range(size*10), size))
    target = random.choice(sorted_arr)
    
    jump_search_times.append(measure_time(jump_search, sorted_arr, target))
    interpolation_search_times.append(measure_time(interpolation_search, sorted_arr, target))
    binary_search_times.append(measure_time(binary_search, sorted_arr, target))

plt.plot(input_sizes, jump_search_times, label="Jump Search")
plt.plot(input_sizes, interpolation_search_times, label="Interpolation Search")
plt.plot(input_sizes, binary_search_times, label="Binary Search")
plt.xlabel('Input Size')
plt.ylabel('Time (seconds)')
plt.title('Jump Search vs Interpolation Search vs Binary Search')
plt.legend()
plt.show()

#question no 3
def exponential_search(arr, target):
    if arr[0] == target:
        return 0
    
    n = len(arr)
    i = 1
    while i < n and arr[i] <= target:
        i *= 2  
    return binary_search(arr[i//2: min(i, n)], target)  
def fibonacci_search(arr, target):
    n = len(arr)
    fib_m_2 = 0 
    fib_m_1 = 1  
    fib = fib_m_1 + fib_m_2 
    
    while fib < n:
        fib_m_2 = fib_m_1
        fib_m_1 = fib
        fib = fib_m_1 + fib_m_2
    
    offset = -1
    while fib > 1:
        i = min(offset + fib_m_2, n-1)
        
        if arr[i] < target:
            fib = fib_m_1
            fib_m_1 = fib_m_2
            fib_m_2 = fib - fib_m_1
            offset = i
        
        elif arr[i] > target:
            fib = fib_m_2
            fib_m_1 -= fib_m_2
            fib_m_2 = fib - fib_m_1
        
        else:
            return i
    
    if fib_m_1 and arr[offset+1] == target:
        return offset+1
    
    return -1
exponential_search_times = []
fibonacci_search_times = []

for size in input_sizes:
    sorted_arr = sorted(random.sample(range(size*10), size))
    target = random.choice(sorted_arr)
    
    exponential_search_times.append(measure_time(exponential_search, sorted_arr, target))
    fibonacci_search_times.append(measure_time(fibonacci_search, sorted_arr, target))

plt.plot(input_sizes, exponential_search_times, label="Exponential Search")
plt.plot(input_sizes, fibonacci_search_times, label="Fibonacci Search")
plt.xlabel('Input Size')
plt.ylabel('Time (seconds)')
plt.title('Exponential Search vs Fibonacci Search')
plt.legend()
plt.show()    
    
    