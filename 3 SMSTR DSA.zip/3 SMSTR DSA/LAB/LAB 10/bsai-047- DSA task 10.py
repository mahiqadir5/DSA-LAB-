#question no 1
def bubble_sort(arr):
    n = len(arr)
    for i in range(n):
        for j in range(0, n-i-1):
            if arr[j] > arr[j+1]:
                arr[j], arr[j+1] = arr[j+1], arr[j]  # Swap
    return arr
def selection_sort(arr):
    n = len(arr)
    for i in range(n):
        min_idx = i
        for j in range(i+1, n):
            if arr[j] < arr[min_idx]:
                min_idx = j
        arr[i], arr[min_idx] = arr[min_idx], arr[i]  # Swap
    return arr
def insertion_sort(arr):
    for i in range(1, len(arr)):
        key = arr[i]
        j = i-1
        while j >= 0 and key < arr[j]:
            arr[j+1] = arr[j]
            j -= 1
        arr[j+1] = key
    return arr

import time
import random

# Measure execution time for different sizes
def measure_time(sorting_algorithm, arr):
    start_time = time.time()
    sorting_algorithm(arr)
    end_time = time.time()
    return end_time - start_time
input_sizes = [100, 500, 1000, 5000, 10000]
for size in input_sizes:
    arr = random.sample(range(size*10), size) 
    print(f"Input size: {size}")
    print(f"Bubble Sort Time: {measure_time(bubble_sort, arr[:])} seconds")
    print(f"Selection Sort Time: {measure_time(selection_sort, arr[:])} seconds")
    print(f"Insertion Sort Time: {measure_time(insertion_sort, arr[:])} seconds")
    print("-" * 40)

import matplotlib.pyplot as plt

input_sizes = [100, 500, 1000, 5000, 10000]
bubble_sort_times = []
selection_sort_times = []
insertion_sort_times = []

for size in input_sizes:
    arr = random.sample(range(size*10), size)
    bubble_sort_times.append(measure_time(bubble_sort, arr[:]))
    selection_sort_times.append(measure_time(selection_sort, arr[:]))
    insertion_sort_times.append(measure_time(insertion_sort, arr[:]))

plt.plot(input_sizes, bubble_sort_times, label="Bubble Sort")
plt.plot(input_sizes, selection_sort_times, label="Selection Sort")
plt.plot(input_sizes, insertion_sort_times, label="Insertion Sort")
plt.xlabel('Input Size')
plt.ylabel('Time (seconds)')
plt.title('Sorting Algorithm Performance Comparison')
plt.legend()
plt.show()

#question no 2

def quick_sort(arr):
    if len(arr) <= 1:
        return arr
    pivot = arr[len(arr) // 2]
    left = [x for x in arr if x < pivot]
    middle = [x for x in arr if x == pivot]
    right = [x for x in arr if x > pivot]
    return quick_sort(left) + middle + quick_sort(right)
def merge_sort(arr):
    if len(arr) <= 1:
        return arr
    mid = len(arr) // 2
    left = merge_sort(arr[:mid])
    right = merge_sort(arr[mid:])
    return merge(left, right)

def merge(left, right):
    result = []
    i = j = 0
    while i < len(left) and j < len(right):
        if left[i] < right[j]:
            result.append(left[i])
            i += 1
        else:
            result.append(right[j])
            j += 1
    result.extend(left[i:])
    result.extend(right[j:])
    return result
# Measure time for Quick Sort and Merge Sort
quick_sort_times = []
merge_sort_times = []

for size in input_sizes:
    arr = random.sample(range(size*10), size)
    quick_sort_times.append(measure_time(quick_sort, arr[:]))
    merge_sort_times.append(measure_time(merge_sort, arr[:]))

plt.plot(input_sizes, quick_sort_times, label="Quick Sort")
plt.plot(input_sizes, merge_sort_times, label="Merge Sort")
plt.xlabel('Input Size')
plt.ylabel('Time (seconds)')
plt.title('Quick Sort vs Merge Sort')
plt.legend()
plt.show()

#question no 3
import heapq

def heap_sort(arr):
    heapq.heapify(arr)  
    return [heapq.heappop(arr) for _ in range(len(arr))]
def counting_sort(arr):
    max_val = max(arr)
    count = [0] * (max_val + 1)
    for num in arr:
        count[num] += 1
    sorted_arr = []
    for i in range(len(count)):
        sorted_arr.extend([i] * count[i])
    return sorted_arr
heap_sort_times = []
counting_sort_times = []

for size in input_sizes:
    arr = random.sample(range(size*10), size)
    heap_sort_times.append(measure_time(heap_sort, arr[:]))
    counting_sort_times.append(measure_time(counting_sort, arr[:]))

plt.plot(input_sizes, heap_sort_times, label="Heap Sort")
plt.plot(input_sizes, counting_sort_times, label="Counting Sort")
plt.xlabel('Input Size')
plt.ylabel('Time (seconds)')
plt.title('Heap Sort vs Counting Sort')
plt.legend()
plt.show()